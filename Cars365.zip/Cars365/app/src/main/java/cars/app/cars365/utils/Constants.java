package cars.app.cars365.utils;

import android.os.Environment;

public class Constants {

    public static final String STORAGE_PATH = "car_files";
    public static final String  FILE_DIRECTORY = Environment.getExternalStorageDirectory().getAbsolutePath() +  "/";


    public static final String COMPANY_PATH = "company_files";

}
